package kalkulatorkrp2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;
import java.util.Locale;

public class KalkulatorKPRPegawaiGUI {
    private static final int BULAN_DALAM_SETAHUN = 12;
    private static final double MAKS_CICILAN_GAJI = 0.30;

    // Konstanta untuk aturan berdasarkan status kepegawaian
    private static class EmployeeRules {
        String status;
        double minInterestRate;
        double maxInterestRate;
        int maxTenureYears;
        double minDownPaymentPercent;
        String riskLevel;

        EmployeeRules(String status, double minRate, double maxRate, int maxYears, double minDP, String risk) {
            this.status = status;
            this.minInterestRate = minRate;
            this.maxInterestRate = maxRate;
            this.maxTenureYears = maxYears;
            this.minDownPaymentPercent = minDP;
            this.riskLevel = risk;
        }
    }

    private static final EmployeeRules[] EMPLOYEE_RULES = {
        new EmployeeRules("PNS", 7.0, 9.0, 20, 5.0, "Rendah"),
        new EmployeeRules("Pegawai BUMN", 9.0, 11.0, 15, 10.0, "Rendah-Menengah"),
        new EmployeeRules("Pegawai Swasta", 12.0, 15.0, 15, 15.0, "Menengah-Tinggi")
    };

    public static void main(String[] args) {
        JFrame frame = new JFrame("Kalkulator KPR Pegawai");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 600);
        frame.setLayout(new BorderLayout(10, 10));

        // Panel untuk input data
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(6, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Masukkan Data Pinjaman"));

        // Komponen input
        JLabel salaryLabel = new JLabel("Gaji Bulanan (Rp): ");
        JFormattedTextField salaryField = createFormattedField();
        
        JLabel principalLabel = new JLabel("Jumlah Pinjaman (Rp): ");
        JFormattedTextField principalField = createFormattedField();
        
        JLabel employeeTypeLabel = new JLabel("Status Kepegawaian: ");
        String[] employeeTypes = {"PNS", "Pegawai BUMN", "Pegawai Swasta"};
        JComboBox<String> employeeTypeCombo = new JComboBox<>(employeeTypes);
        
        JLabel annualInterestRateLabel = new JLabel("Suku Bunga Tahunan (%): ");
        JFormattedTextField annualInterestRateField = createFormattedField();
        
        JLabel termInYearsLabel = new JLabel("Jangka Waktu (tahun): ");
        JFormattedTextField termInYearsField = createFormattedField();
        
        JLabel downPaymentLabel = new JLabel("Uang Muka (Rp): ");
        JFormattedTextField downPaymentField = createFormattedField();

        // Info Panel untuk menampilkan aturan
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BorderLayout());
        infoPanel.setBorder(BorderFactory.createTitledBorder("Informasi Status Kepegawaian"));
        JTextArea infoArea = new JTextArea(4, 40);
        infoArea.setEditable(false);
        infoArea.setLineWrap(true);
        infoArea.setWrapStyleWord(true);
        infoPanel.add(new JScrollPane(infoArea), BorderLayout.CENTER);

        // Update info ketika status kepegawaian berubah
        employeeTypeCombo.addActionListener(e -> {
            String selectedType = (String) employeeTypeCombo.getSelectedItem();
            for (EmployeeRules rules : EMPLOYEE_RULES) {
                if (rules.status.equals(selectedType)) {
                    infoArea.setText(String.format(
                        "Status: %s\n" +
                        "Suku Bunga: %.1f%% - %.1f%%\n" +
                        "Maksimal Tenor: %d tahun\n" +
                        "Minimal Uang Muka: %.1f%%\n" +
                        "Tingkat Risiko: %s",
                        rules.status, rules.minInterestRate, rules.maxInterestRate,
                        rules.maxTenureYears, rules.minDownPaymentPercent, rules.riskLevel
                    ));
                    // Set default interest rate
                    annualInterestRateField.setText(String.format("%.1f", rules.minInterestRate));
                    break;
                }
            }
        });

        // Menambahkan komponen ke panel
        inputPanel.add(salaryLabel);
        inputPanel.add(salaryField);
        inputPanel.add(principalLabel);
        inputPanel.add(principalField);
        inputPanel.add(employeeTypeLabel);
        inputPanel.add(employeeTypeCombo);
        inputPanel.add(annualInterestRateLabel);
        inputPanel.add(annualInterestRateField);
        inputPanel.add(termInYearsLabel);
        inputPanel.add(termInYearsField);
        inputPanel.add(downPaymentLabel);
        inputPanel.add(downPaymentField);

        // Panel untuk hasil perhitungan
        JPanel resultPanel = new JPanel();
        resultPanel.setLayout(new GridLayout(6, 1, 5, 5));
        resultPanel.setBorder(BorderFactory.createTitledBorder("Hasil Perhitungan"));

        JLabel monthlyPaymentLabel = new JLabel("Cicilan Bulanan: ");
        JLabel totalPaymentLabel = new JLabel("Total Pembayaran: ");
        JLabel maxLoanLabel = new JLabel("Maksimal Pinjaman: ");
        JLabel downPaymentAmountLabel = new JLabel("Jumlah Uang Muka: ");
        JLabel downPaymentPercentLabel = new JLabel("Persentase Uang Muka: ");
        JLabel statusLabel = new JLabel("Status Kelayakan: ");
        
        resultPanel.add(monthlyPaymentLabel);
        resultPanel.add(totalPaymentLabel);
        resultPanel.add(maxLoanLabel);
        resultPanel.add(downPaymentAmountLabel);
        resultPanel.add(downPaymentPercentLabel);
        resultPanel.add(statusLabel);

        // Panel tombol
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());

        JButton calculateButton = new JButton("Hitung");
        JButton resetButton = new JButton("Reset");

        // Reset button action
        resetButton.addActionListener(e -> {
            salaryField.setText("");
            principalField.setText("");
            termInYearsField.setText("");
            downPaymentField.setText("");
            monthlyPaymentLabel.setText("Cicilan Bulanan: ");
            totalPaymentLabel.setText("Total Pembayaran: ");
            maxLoanLabel.setText("Maksimal Pinjaman: ");
            downPaymentAmountLabel.setText("Jumlah Uang Muka: ");
            downPaymentPercentLabel.setText("Persentase Uang Muka: ");
            statusLabel.setText("Status Kelayakan: ");
        });

        // Calculate button action
        calculateButton.addActionListener(e -> {
            try {
                String selectedType = (String) employeeTypeCombo.getSelectedItem();
                EmployeeRules currentRules = null;
                for (EmployeeRules rules : EMPLOYEE_RULES) {
                    if (rules.status.equals(selectedType)) {
                        currentRules = rules;
                        break;
                    }
                }

                double salary = parseFormattedInput(salaryField.getText());
                double principal = parseFormattedInput(principalField.getText());
                double annualInterestRate = Double.parseDouble(annualInterestRateField.getText().replace(".", ""));
                int termInYears = Integer.parseInt(termInYearsField.getText().replace(".", ""));
                double downPayment = parseFormattedInput(downPaymentField.getText());
                
                // Validasi berdasarkan aturan status kepegawaian
                if (currentRules != null) {
                    // Validasi jangka waktu
                    if (termInYears > currentRules.maxTenureYears) {
                        JOptionPane.showMessageDialog(frame, 
                            String.format("Maksimal jangka waktu untuk %s adalah %d tahun.", 
                            currentRules.status, currentRules.maxTenureYears),
                            "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    // Validasi suku bunga
                    if (annualInterestRate < currentRules.minInterestRate || 
                        annualInterestRate > currentRules.maxInterestRate) {
                        JOptionPane.showMessageDialog(frame,
                            String.format("Suku bunga untuk %s harus antara %.1f%% - %.1f%%",
                            currentRules.status, currentRules.minInterestRate, currentRules.maxInterestRate),
                            "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    // Validasi minimal uang muka
                    double downPaymentPercent = (downPayment / principal) * 100;
                    if (downPaymentPercent < currentRules.minDownPaymentPercent) {
                        JOptionPane.showMessageDialog(frame,
                            String.format("Minimal uang muka untuk %s adalah %.1f%%",
                            currentRules.status, currentRules.minDownPaymentPercent),
                            "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                // Validasi input dasar
                if (salary <= 0 || principal <= 0 || annualInterestRate <= 0 || termInYears <= 0 || downPayment < 0) {
                    JOptionPane.showMessageDialog(frame, "Harap masukkan nilai yang valid dan positif.", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Perhitungan
                double maxMonthlyPayment = salary * MAKS_CICILAN_GAJI;
                double loanAmount = principal - downPayment;
                double monthlyInterestRate = (annualInterestRate / 100) / BULAN_DALAM_SETAHUN;
                int numberOfPayments = termInYears * BULAN_DALAM_SETAHUN;
                
                double monthlyPayment = loanAmount * (
                    (monthlyInterestRate * Math.pow(1 + monthlyInterestRate, numberOfPayments)) / 
                    (Math.pow(1 + monthlyInterestRate, numberOfPayments) - 1)
                );

                double maxLoanPossible = maxMonthlyPayment * (
                    (Math.pow(1 + monthlyInterestRate, numberOfPayments) - 1) /
                    (monthlyInterestRate * Math.pow(1 + monthlyInterestRate, numberOfPayments))
                );

                double totalPayment = (monthlyPayment * numberOfPayments) + downPayment;
                double downPaymentPercent = (downPayment / principal) * 100;

                // Format currency
                NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
                NumberFormat percentFormat = NumberFormat.getNumberInstance(new Locale("id", "ID"));
                percentFormat.setMaximumFractionDigits(2);
                
                // Update labels
                monthlyPaymentLabel.setText("Cicilan Bulanan: " + currencyFormat.format(monthlyPayment));
                totalPaymentLabel.setText("Total Pembayaran: " + currencyFormat.format(totalPayment));
                maxLoanLabel.setText("Maksimal Pinjaman: " + currencyFormat.format(maxLoanPossible));
                downPaymentAmountLabel.setText("Jumlah Uang Muka: " + currencyFormat.format(downPayment));
                downPaymentPercentLabel.setText("Persentase Uang Muka: " + percentFormat.format(downPaymentPercent) + "%");
                
                boolean isEligible = monthlyPayment <= maxMonthlyPayment;
                String statusText = isEligible ? 
                    "Status Kelayakan: LAYAK (Cicilan di bawah 30% gaji)" :
                    "Status Kelayakan: TIDAK LAYAK (Cicilan melebihi 30% gaji)";
                statusLabel.setText(statusText);
                statusLabel.setForeground(isEligible ? new Color(0, 150, 0) : Color.RED);

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Harap masukkan nilai yang valid.", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Add buttons to panel
        buttonPanel.add(calculateButton);
        buttonPanel.add(resetButton);

        // Create main panel to hold all components
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Add panels to main panel
        mainPanel.add(inputPanel, BorderLayout.NORTH);
        mainPanel.add(infoPanel, BorderLayout.CENTER);
        mainPanel.add(resultPanel, BorderLayout.SOUTH);

        // Add main panel and button panel to frame
        frame.add(mainPanel, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        // Trigger initial info update
        employeeTypeCombo.setSelectedIndex(0);

        // Set frame properties
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private static JFormattedTextField createFormattedField() {
        NumberFormat format = NumberFormat.getNumberInstance(new Locale("id", "ID"));
        format.setGroupingUsed(true);
        JFormattedTextField field = new JFormattedTextField(format);
        field.setColumns(15);
        return field;
    }

    private static double parseFormattedInput(String input) {
        return Double.parseDouble(input.replace(".", "").replace(",", "."));
    }
}